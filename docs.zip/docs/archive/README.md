This folder contains deprecated or replaced specifications. 
Files are retained here for reference but should not be updated or used for implementation.
