# template-sets-risks – Risks & Mitigations

See `template-sets-risks.md` for implementation details.

## Risk 1: [Risk Summary]
- **Issue**: [Description]
- **Mitigation**: [Mitigation steps]