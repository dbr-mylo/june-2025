# editor-preview-split-zoom-risks – Risks & Mitigations

See `editor-preview-split-zoom-risks.md` for implementation details.

## Risk 1: [Risk Summary]
- **Issue**: [Description]
- **Mitigation**: [Mitigation steps]